function submit(){
    registForm = document.getElementById("isiform");
    username = document.getElementById("username");
    email = document.getElementById("email");
    phoneNumber = document.getElementById("phoneNumber");
    ramen = document.getElementById("ramen");
    dryRamen = document.getElementById("dryramen");
    agree = document.getElementById("agree");
    error = document.getElementById("error");

    if(username.value.length < 5){
        error.innerHTML = "Name must be at least 5 characters";
        alert("Name must be at least 5 characters");
    }
    else if(!email.value.endsWith("@gmail.com")){
        error.innerHTML = "Email must end with '@gmail.com'";
        alert("Email must end with '@gmail.com'");
    }
    else if(phoneNumber.value.length<11 || phoneNumber.value.length>13){
        error.innerHTML = "Please fill the number properly (11-13 Numbers)!";
        alert("Please fill the number properly (1-13 Numbers)!");
    }
    else if(!(ramen.checked || dryRamen.checked)){
        error.innerHTML = "Preferences  must be picked!";
        alert("Preferences  must be picked!");
    }
    else if(!agree.checked){
        error.innerHTML = "You must agree to the Terms & Conditions!";
        alert("You must agree to the Terms & Conditions!");
    }
    else{
        error.innerHTML = "";
        alert("Successfull");
        registForm.submit();
    }
}